import {getStore} from '@netlify/blobs';
import {makeHandler} from '../lib/handler.mjs';
let h;
export default async (req)=>{h=h||makeHandler(getStore({name:'vasya',consistency:'strong'}));return h(req)};
export const config={path:'/api/*'};
